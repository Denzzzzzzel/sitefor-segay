// === Gallery Module ===
export class Gallery {
  constructor() {
    this.modal = null;
    this.clickHandler = null;
    this.closeHandler = null;
    this.keyHandler = null;
    this.init();
  }

  init() {
    this.createModal();
    this.setupEventListeners();
  }

  createModal() {
    this.modal = document.createElement('div');
    this.modal.id = 'gallery_modal';
    this.modal.className = 'modal';
    this.modal.setAttribute('aria-hidden', 'true');
    this.modal.setAttribute('role', 'dialog');
    this.modal.setAttribute('aria-label', 'Просмотр фото');
    
    this.modal.innerHTML = `
      <div class="gallery-container" style="position: relative; max-width: 90vw; max-height: 90vh; display: flex; align-items: center; justify-content: center;">
        <img id="gallery-image" alt="Просмотр фото" style="max-width: 100%; max-height: 90vh; border-radius: 0.6rem; object-fit: contain;">
        <button id="gallery-close" class="gallery-close" type="button" aria-label="Закрыть просмотр фото">
          <span class="gallery-close-line"></span>
          <span class="gallery-close-line"></span>
        </button>
      </div>
    `;
    
    document.body.appendChild(this.modal);
  }

  setupEventListeners() {
    this.clickHandler = e => {
      const btn = e.target.closest('.gallery-item');
      if (btn) {
        e.preventDefault();
        const src = btn.getAttribute('data-src');
        if (src) this.openGallery(src);
      }
      
      if (e.target.id === 'gallery-close' || e.target === this.modal) {
        this.closeGallery();
      }
    };
    
    this.closeHandler = () => this.closeGallery();
    
    this.keyHandler = e => {
      if (e.key === 'Escape' && this.modal.style.display === 'flex') {
        this.closeGallery();
      }
    };
    
    document.addEventListener('click', this.clickHandler);
    document.addEventListener('keydown', this.keyHandler);
    
    // Добавляем обработчик после создания модального окна
    setTimeout(() => {
      const closeBtn = document.getElementById('gallery-close');
      if (closeBtn) {
        closeBtn.addEventListener('click', this.closeHandler);
      }
    }, 100);
  }

  openGallery(src) {
    const img = document.getElementById('gallery-image');
    img.src = src;
    this.modal.style.display = 'flex';
    this.modal.setAttribute('aria-hidden', 'false');
  }

  closeGallery() {
    this.modal.style.display = 'none';
    this.modal.setAttribute('aria-hidden', 'true');
  }

  destroy() {
    if (this.clickHandler) {
      document.removeEventListener('click', this.clickHandler);
    }
    
    if (this.keyHandler) {
      document.removeEventListener('keydown', this.keyHandler);
    }
    
    if (this.closeHandler) {
      const closeBtn = document.getElementById('gallery-close');
      if (closeBtn) {
        closeBtn.removeEventListener('click', this.closeHandler);
      }
    }
    
    if (this.modal && this.modal.parentNode) {
      this.modal.parentNode.removeChild(this.modal);
    }
    
    this.modal = null;
    this.clickHandler = null;
    this.closeHandler = null;
    this.keyHandler = null;
  }
}
