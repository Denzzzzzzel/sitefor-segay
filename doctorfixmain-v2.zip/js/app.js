// === Main Application Module ===
import { LeadFormHandler, QuestionFormHandler } from './modules/forms.js';
import { Gallery } from './modules/gallery.js';
import { MobileMenu } from './modules/mobile-menu.js';
import { Breadcrumbs } from './modules/breadcrumbs.js';
import { ErrorHandler } from './modules/error-handler.js';
import { PremiumForm } from './modules/premium-form.js';
import { $, $$, toast, formatPhone } from './modules/utils.js';

class App {
  constructor() {
    this.modules = {};
    this.init();
  }

  init() {
    this.setupModules();
    this.setupGlobalEventListeners();
  }

  setupModules() {
    // Инициализация обработчика ошибок
    this.modules.errorHandler = new ErrorHandler();
    
    // Инициализация модулей
    this.modules.leadForm = new LeadFormHandler();
    
    // Инициализация формы вопросов только если она есть на странице
    if (document.querySelector('#question_form')) {
      this.modules.questionForm = new QuestionFormHandler();
    }
    
    this.modules.gallery = new Gallery();
    this.modules.mobileMenu = new MobileMenu();
    this.modules.breadcrumbs = new Breadcrumbs();
    
    // Инициализация премиум формы
    if (document.querySelector('.premium-form')) {
      this.modules.premiumForm = new PremiumForm();
    }

  }

  setupGlobalEventListeners() {
    // Phone clicks
    $$('[data-track=phone]').forEach(el => {
      el.addEventListener('click', () => this.trackGoal("click_phone"));
    });

    // Phone button clicks
    document.addEventListener('click', (e) => {
      if (e.target.dataset.phone) {
        window.location.href = `tel:${e.target.dataset.phone}`;
      }
    });

    // Modal handling
    this.setupModalHandling();
  }

  trackGoal(goal) {
    console.log('Goal would be tracked:', goal);
  }

  setupModalHandling() {
    const modal = document.getElementById('success_modal');
    const modalClose = document.getElementById('modal_close');
    
    if (modalClose) {
      modalClose.addEventListener('click', () => this.closeModal());
    }
    
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) this.closeModal();
      });
    }
    
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal && modal.style.display === 'flex') {
        this.closeModal();
      }
    });
  }

  closeModal() {
    const modal = document.getElementById('success_modal');
    if (modal) {
      modal.style.display = 'none';
    }
  }

  destroy() {
    // Cleanup all modules
    Object.values(this.modules).forEach(module => {
      if (module.destroy) {
        module.destroy();
      }
    });
  }
}

// Инициализация приложения
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.app) {
      window.app = new App();
    }
  });
} else {
  if (!window.app) {
    window.app = new App();
  }
}

// Защита от повторной инициализации
if (window.app && window.app.destroy) {
  window.app.destroy();
}
