<?php
require_once 'telegram-sender.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Проверяем метод запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Получаем данные из запроса
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Валидация обязательных полей
$requiredFields = ['phone'];
foreach ($requiredFields as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

// Проверка honeypot поля
if (!empty($input['company'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Spam detected']);
    exit;
}

// Очистка данных
$name = isset($input['name']) ? trim($input['name']) : '';
$phone = trim($input['phone']);
$service = isset($input['service']) ? trim($input['service']) : '';
$area = isset($input['area']) ? trim($input['area']) : '';
$comment = isset($input['comment']) ? trim($input['comment']) : '';
$question = isset($input['question']) ? trim($input['question']) : '';

// Валидация телефона
if (!preg_match('/^[\+]?[0-9\s\-\(\)]{10,}$/', $phone)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid phone number']);
    exit;
}

// Подготовка данных для сохранения
$formData = [
    'name' => $name,
    'phone' => $phone,
    'service' => $service,
    'area' => $area,
    'comment' => $comment,
    'question' => $question,
    'timestamp' => date('Y-m-d H:i:s'),
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
];

// Инициализация Telegram отправителя
$telegram = new TelegramSender();

// Отправка в Telegram (если настроено)
$telegramSent = false;
if ($telegram->isConfigured()) {
    if (!empty($question)) {
        // Это вопрос
        $telegramSent = $telegram->sendQuestion($formData);
    } else {
        // Это заявка
        $telegramSent = $telegram->sendLead($formData);
    }
}

// Логирование заявки (для отладки)
error_log('Form submission: ' . json_encode($formData));
error_log('Telegram sent: ' . ($telegramSent ? 'YES' : 'NO'));

// Успешный ответ
echo json_encode([
    'success' => true,
    'message' => 'Form submitted successfully',
    'data' => [
        'name' => $name,
        'phone' => $phone
    ]
]);
?>
