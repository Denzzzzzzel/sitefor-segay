<?php
class TelegramSender {
    private $config;
    private $botToken;
    private $chatId;
    private $apiUrl;

    public function __construct() {
        $this->config = include 'telegram-config.php';
        $this->botToken = $this->config['bot_token'];
        $this->chatId = $this->config['chat_id'];
        $this->apiUrl = $this->config['api_url'] . $this->botToken;
    }

    /**
     * Отправка заявки в Telegram
     */
    public function sendLead($formData) {
        $message = $this->formatLeadMessage($formData);
        return $this->sendMessage($message);
    }

    /**
     * Отправка вопроса в Telegram
     */
    public function sendQuestion($formData) {
        $message = $this->formatQuestionMessage($formData);
        return $this->sendMessage($message);
    }

    /**
     * Форматирование сообщения для заявки
     */
    private function formatLeadMessage($data) {
        $message = "🆕 <b>Новая заявка на ремонт</b>\n\n";
        
        if (!empty($data['name'])) {
            $message .= "👤 <b>Имя:</b> " . htmlspecialchars($data['name']) . "\n";
        }
        
        $message .= "📞 <b>Телефон:</b> " . htmlspecialchars($data['phone']) . "\n";
        
        if (!empty($data['service'])) {
            $message .= "🔧 <b>Услуга:</b> " . htmlspecialchars($data['service']) . "\n";
        }
        
        if (!empty($data['area'])) {
            $message .= "📍 <b>Район:</b> " . htmlspecialchars($data['area']) . "\n";
        }
        
        if (!empty($data['comment'])) {
            $message .= "💬 <b>Комментарий:</b> " . htmlspecialchars($data['comment']) . "\n";
        }
        
        $message .= "\n⏰ <b>Время:</b> " . $data['timestamp'] . "\n";
        $message .= "🌐 <b>IP:</b> " . $data['ip'];
        
        return $message;
    }

    /**
     * Форматирование сообщения для вопроса
     */
    private function formatQuestionMessage($data) {
        $message = "❓ <b>Новый вопрос от клиента</b>\n\n";
        
        if (!empty($data['name'])) {
            $message .= "👤 <b>Имя:</b> " . htmlspecialchars($data['name']) . "\n";
        }
        
        $message .= "📞 <b>Телефон:</b> " . htmlspecialchars($data['phone']) . "\n";
        $message .= "❓ <b>Вопрос:</b> " . htmlspecialchars($data['question']) . "\n";
        
        $message .= "\n⏰ <b>Время:</b> " . $data['timestamp'] . "\n";
        $message .= "🌐 <b>IP:</b> " . $data['ip'];
        
        return $message;
    }

    /**
     * Отправка сообщения в Telegram
     */
    private function sendMessage($message) {
        if (empty($this->botToken) || empty($this->chatId) || 
            $this->botToken === 'YOUR_BOT_TOKEN_HERE' || 
            $this->chatId === 'YOUR_CHAT_ID_HERE') {
            
            error_log('Telegram not configured properly');
            return false;
        }

        $data = [
            'chat_id' => $this->chatId,
            'text' => $message,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true
        ];

        $url = $this->apiUrl . '/sendMessage';
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            error_log('Telegram cURL error: ' . $error);
            return false;
        }

        if ($httpCode !== 200) {
            error_log('Telegram API error: HTTP ' . $httpCode . ', Response: ' . $response);
            return false;
        }

        $result = json_decode($response, true);
        if (!$result['ok']) {
            error_log('Telegram API error: ' . $result['description']);
            return false;
        }

        return true;
    }

    /**
     * Проверка конфигурации
     */
    public function isConfigured() {
        return !empty($this->botToken) && 
               !empty($this->chatId) && 
               $this->botToken !== 'YOUR_BOT_TOKEN_HERE' && 
               $this->chatId !== 'YOUR_CHAT_ID_HERE';
    }
}
?>
