// === Breadcrumbs Module ===
export class Breadcrumbs {
  constructor() {
    this.breadcrumbList = document.querySelector('.breadcrumb-list');
    this.init();
  }

  init() {
    if (!this.breadcrumbList) return;
    
    this.setupBreadcrumbs();
  }

  setupBreadcrumbs() {
    // Добавляем анимации для breadcrumbs
    const breadcrumbItems = this.breadcrumbList.querySelectorAll('li');
    
    breadcrumbItems.forEach((item, index) => {
      // Добавляем задержку для анимации появления
      item.style.opacity = '0';
      item.style.transform = 'translateY(10px)';
      item.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      
      setTimeout(() => {
        item.style.opacity = '1';
        item.style.transform = 'translateY(0)';
      }, index * 100);
    });
  }

  destroy() {
    // Cleanup if needed
  }
}
