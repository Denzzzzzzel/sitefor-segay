// === Utility Functions ===
export const $ = (q, r = document) => r.querySelector(q);
export const $$ = (q, r = document) => Array.from(r.querySelectorAll(q));

let toastEl;

export function ensureToastEl() {
  if (!toastEl) {
    toastEl = document.querySelector('.toast') || document.createElement('div');
    toastEl.className = 'toast';
    if (!toastEl.isConnected) document.body.appendChild(toastEl);
  }
  return toastEl;
}

export function toast(message) {
  const el = ensureToastEl();
  el.textContent = message;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2500);
}

export function formatPhone(value) {
  const digits = value.replace(/\D/g, '');
  const formatted = ['+7 ', '(', digits.slice(1, 4), ') ', digits.slice(4, 7), '-', digits.slice(7, 9), '-', digits.slice(9, 11)].join('');
  return formatted.replace(/[-()\s]+$/, '').trim();
}
