// === Form Handling Module ===
import { $, toast, formatPhone } from './utils.js';

export class FormHandler {
  constructor(formId, apiEndpoint) {
    this.formId = formId;
    this.form = $(formId);
    this.apiEndpoint = apiEndpoint;
    
    if (!this.form) {
      console.warn('FormHandler: Form not found:', formId);
      return;
    }
    
    this.honeypot = this.form.querySelector('#hp_field, #question_hp_field');
    this.init();
  }

  init() {
    if (!this.form) return;
    
    this.setupPhoneFormatting();
    this.setupSubmitHandler();
  }

  setupPhoneFormatting() {
    if (!this.form) return;
    
    const phoneInput = this.form.querySelector('input[name="phone"]');
    if (phoneInput) {
      phoneInput.addEventListener('input', e => {
        let digits = e.target.value.replace(/\D/g, '');
        if (!digits.startsWith('7')) digits = '7' + digits;
        e.target.value = formatPhone(digits);
      });
    }
  }

  setupSubmitHandler() {
    if (!this.form) return;
    
    this.form.addEventListener('submit', async e => {
      e.preventDefault();
      this.trackGoal("submit_try");
      
      if (this.honeypot && this.honeypot.value) return;
      
      const btn = this.form.querySelector('button[type="submit"]');
      if (!btn) return;
      
      const originalText = btn.textContent;
      
      btn.disabled = true;
      btn.textContent = 'Отправляем…';
      
      const data = Object.fromEntries(new FormData(this.form).entries());
      
      try {
        const response = await fetch(this.apiEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (!response.ok) {
          throw new Error(result.error || 'Ошибка сервера');
        }
        
        this.form.reset();
        this.onSuccess();
        this.trackGoal("lead");
      } catch (err) {
        toast('Произошла ошибка при отправке. Попробуйте снова.');
      } finally {
        btn.disabled = false;
        btn.textContent = originalText;
      }
    });
  }

  onSuccess() {
    // Override in child classes
  }

  trackGoal(goal) {
    console.log('Form goal would be tracked:', goal);
  }
}

export class LeadFormHandler extends FormHandler {
  constructor() {
    super('#lead_form', 'api/send-form.php');
  }

  onSuccess() {
    const modal = $('#success_modal');
    if (modal) {
      modal.style.display = 'flex';
      const focusable = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (focusable) focusable.focus();
    } else {
      toast('Заявка успешно отправлена!');
    }
  }
}

export class QuestionFormHandler extends FormHandler {
  constructor() {
    super('#question_form, #question_form_prices, #question_form_gallery', 'api/send-form.php');
  }

  onSuccess() {
    const modal = $('#success_modal');
    if (modal) {
      modal.style.display = 'flex';
      const focusable = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (focusable) focusable.focus();
    } else {
      toast('Вопрос успешно отправлен!');
    }
  }
}
