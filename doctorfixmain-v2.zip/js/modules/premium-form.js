// === Premium Form Module ===
export class PremiumForm {
  constructor() {
    this.form = document.getElementById('lead_form');
    this.currentStep = 1;
    this.totalSteps = 3;
    this.init();
  }

  init() {
    if (!this.form) {
      console.log('PremiumForm: Form not found');
      return;
    }

    console.log('PremiumForm: Initializing premium form...');
    this.setupEventListeners();
    this.updateNavigation();
  }

  setupEventListeners() {
    // Navigation buttons
    const nextBtn = document.getElementById('nextStep');
    const prevBtn = document.getElementById('prevStep');
    const submitBtn = document.getElementById('lead_submit');

    if (nextBtn) {
      nextBtn.addEventListener('click', () => this.nextStep());
    }

    if (prevBtn) {
      prevBtn.addEventListener('click', () => this.prevStep());
    }

    if (submitBtn) {
      submitBtn.addEventListener('click', (e) => this.handleSubmit(e));
    }

    // Form validation on input
    const inputs = this.form.querySelectorAll('.premium-input, .premium-select, .premium-textarea');
    inputs.forEach(input => {
      input.addEventListener('input', () => this.validateCurrentStep());
      input.addEventListener('blur', () => this.validateCurrentStep());
    });

    // Phone number formatting
    const phoneInput = document.getElementById('lead_phone');
    if (phoneInput) {
      phoneInput.addEventListener('input', (e) => this.formatPhoneNumber(e));
    }
  }

  nextStep() {
    if (this.validateCurrentStep()) {
      this.currentStep++;
      this.showStep(this.currentStep);
      this.updateNavigation();
      this.animateStepTransition();
    }
  }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.showStep(this.currentStep);
      this.updateNavigation();
      this.animateStepTransition();
    }
  }

  showStep(step) {
    // Hide all steps
    const steps = this.form.querySelectorAll('.form-step');
    steps.forEach(stepEl => {
      stepEl.classList.remove('active');
    });

    // Show current step
    const currentStepEl = this.form.querySelector(`[data-step="${step}"]`);
    if (currentStepEl) {
      currentStepEl.classList.add('active');
    }
  }

  validateCurrentStep() {
    const currentStepEl = this.form.querySelector(`[data-step="${this.currentStep}"]`);
    if (!currentStepEl) return false;

    const requiredInputs = currentStepEl.querySelectorAll('input[required], select[required]');
    let isValid = true;

    requiredInputs.forEach(input => {
      if (!input.value.trim()) {
        isValid = false;
        this.showInputError(input, 'Это поле обязательно для заполнения');
      } else {
        this.clearInputError(input);
      }
    });

    // Special validation for phone
    const phoneInput = currentStepEl.querySelector('input[name="phone"]');
    if (phoneInput && phoneInput.value) {
      if (!this.isValidPhone(phoneInput.value)) {
        isValid = false;
        this.showInputError(phoneInput, 'Введите корректный номер телефона');
      }
    }

    return isValid;
  }

  isValidPhone(phone) {
    const phoneRegex = /^(\+7|7|8)?[\s\-]?\(?[489][0-9]{2}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
  }

  showInputError(input, message) {
    this.clearInputError(input);
    
    const errorEl = document.createElement('div');
    errorEl.className = 'input-error';
    errorEl.textContent = message;
    errorEl.style.cssText = `
      color: #ef4444;
      font-size: 0.8rem;
      margin-top: 0.25rem;
      animation: errorShake 0.3s ease-in-out;
    `;
    
    input.parentNode.appendChild(errorEl);
    input.style.borderColor = '#ef4444';
  }

  clearInputError(input) {
    const errorEl = input.parentNode.querySelector('.input-error');
    if (errorEl) {
      errorEl.remove();
    }
    input.style.borderColor = '';
  }

  formatPhoneNumber(e) {
    let value = e.target.value.replace(/\D/g, '');
    
    if (value.startsWith('8')) {
      value = '7' + value.slice(1);
    }
    
    if (value.startsWith('7')) {
      value = value.slice(0, 11);
      let formatted = '+7';
      
      if (value.length > 1) {
        formatted += ' (' + value.slice(1, 4);
      }
      if (value.length >= 5) {
        formatted += ') ' + value.slice(4, 7);
      }
      if (value.length >= 8) {
        formatted += '-' + value.slice(7, 9);
      }
      if (value.length >= 10) {
        formatted += '-' + value.slice(9, 11);
      }
      
      e.target.value = formatted;
    }
  }

  updateNavigation() {
    const nextBtn = document.getElementById('nextStep');
    const prevBtn = document.getElementById('prevStep');
    const submitBtn = document.getElementById('lead_submit');

    // Update prev button
    if (prevBtn) {
      prevBtn.disabled = this.currentStep === 1;
    }

    // Update next/submit buttons
    if (this.currentStep < this.totalSteps) {
      if (nextBtn) nextBtn.style.display = 'flex';
      if (submitBtn) submitBtn.style.display = 'none';
    } else {
      if (nextBtn) nextBtn.style.display = 'none';
      if (submitBtn) submitBtn.style.display = 'flex';
    }
  }

  animateStepTransition() {
    const currentStepEl = this.form.querySelector(`[data-step="${this.currentStep}"]`);
    if (currentStepEl) {
      currentStepEl.style.animation = 'none';
      setTimeout(() => {
        currentStepEl.style.animation = 'stepSlideIn 0.5s ease-out';
      }, 10);
    }
  }

  async handleSubmit(e) {
    e.preventDefault();
    
    if (!this.validateCurrentStep()) {
      return;
    }

    const submitBtn = document.getElementById('lead_submit');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoading = submitBtn.querySelector('.btn-loading');

    // Show loading state
    if (btnText) btnText.style.display = 'none';
    if (btnLoading) btnLoading.style.display = 'flex';
    submitBtn.disabled = true;

    try {
      // Simulate form submission
      await this.submitForm();
      
      // Show success
      this.showSuccessMessage();
      
    } catch (error) {
      console.error('Form submission error:', error);
      this.showErrorMessage();
    } finally {
      // Reset button state
      if (btnText) btnText.style.display = 'flex';
      if (btnLoading) btnLoading.style.display = 'none';
      submitBtn.disabled = false;
    }
  }

  async submitForm() {
    // Simulate API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate success
        resolve();
      }, 2000);
    });
  }

  showSuccessMessage() {
    // Create success modal or redirect
    const modal = document.getElementById('success_modal');
    if (modal) {
      modal.style.display = 'flex';
    }
  }

  showErrorMessage() {
    // Show error message
    alert('Произошла ошибка при отправке формы. Пожалуйста, попробуйте еще раз или позвоните нам.');
  }

  destroy() {
    console.log('PremiumForm: Destroyed');
  }
}
