// === Mobile Menu Module ===
export class MobileMenu {
  constructor() {
    this.overlay = document.getElementById('mobileOverlay');
    this.menuBtn = document.querySelector('.burger');
    this.backdrop = document.getElementById('mobileBackdrop');
    this.closeBtn = document.querySelector('.mobile-menu__close');
    this.init();
  }

  init() {
    if (!this.overlay || !this.menuBtn || !this.backdrop) return;
    
    this.setupEventListeners();
  }

  setupEventListeners() {
    this.menuBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isOpen = this.overlay.getAttribute('data-open') === 'true';
      isOpen ? this.closeMenu() : this.openMenu();
    });

    this.backdrop.addEventListener('click', () => this.closeMenu());
    
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.overlay.dataset.open === 'true') {
        this.closeMenu();
      }
    });

    if (this.closeBtn) {
      this.closeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.closeMenu();
      });
    }

    document.addEventListener('click', (e) => {
      if (e.target.closest('a[data-nav]')) {
        this.closeMenu();
      }
    });
  }

  openMenu() {
    this.overlay.dataset.open = 'true';
    this.menuBtn.setAttribute('aria-expanded', 'true');
    this.overlay.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    document.body.classList.add('nav-open');
    
    // Start animation after aria-hidden is set to false
    requestAnimationFrame(() => {
      this.overlay.dataset.animate = 'in';
      // Focus management after animation starts
      setTimeout(() => {
        if (this.closeBtn) {
          this.closeBtn.focus();
        }
      }, 100);
    });
  }

  closeMenu() {
    this.overlay.dataset.animate = '';
    this.menuBtn.setAttribute('aria-expanded', 'false');
    this.overlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    document.body.classList.remove('nav-open');
    
    // Return focus to menu button after closing
    setTimeout(() => {
      this.overlay.dataset.open = 'false';
      if (this.menuBtn) {
        this.menuBtn.focus();
      }
    }, 200);
  }

  destroy() {
    // Cleanup if needed
  }
}
