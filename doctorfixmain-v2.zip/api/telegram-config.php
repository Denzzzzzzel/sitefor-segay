<?php
// Конфигурация Telegram бота
// Получите эти данные у @BotFather в Telegram

return [
    'bot_token' => 'YOUR_BOT_TOKEN_HERE', // Токен бота от @BotFather
    'chat_id' => 'YOUR_CHAT_ID_HERE',    // ID чата или канала для получения сообщений
    'api_url' => 'https://api.telegram.org/bot'
];
?>
