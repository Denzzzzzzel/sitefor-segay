// === Error Handler Module ===
export class ErrorHandler {
  constructor() {
    this.init();
  }

  init() {
    this.setupGlobalErrorHandling();
  }

  setupGlobalErrorHandling() {
    // Обработка необработанных ошибок JavaScript
    window.addEventListener('error', (event) => {
      console.error('JavaScript Error:', event.error);
      this.handleError(event.error);
    });

    // Обработка необработанных отклонений Promise
    window.addEventListener('unhandledrejection', (event) => {
      console.error('Unhandled Promise Rejection:', event.reason);
      this.handleError(event.reason);
    });
  }

  handleError(error) {
    // Логируем ошибку в консоль для разработки
    console.error('Error handled:', error);
    
    // В продакшене здесь можно отправить ошибку на сервер
    // this.reportError(error);
  }

  reportError(error) {
    // Отправка ошибки на сервер для мониторинга
    // fetch('/api/error-report', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({
    //     message: error.message,
    //     stack: error.stack,
    //     url: window.location.href,
    //     timestamp: new Date().toISOString()
    //   })
    // }).catch(() => {
    //   // Игнорируем ошибки при отправке отчета об ошибке
    // });
  }

  destroy() {
    // Cleanup if needed
  }
}
